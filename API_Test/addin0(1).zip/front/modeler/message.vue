<template>
  <section>
    <el-button type="warning" @click="onClick">样例</el-button>
  </section>
</template>

<script>
export default {
  name: 'message',
  data() {
    return {
      msg: "Hello World",
    }
  },
  methods: {
    onClick() {
      this.$message({
        message: this.msg,
        type: "success"
      });
    }
  }
}
</script>

<style>

</style>