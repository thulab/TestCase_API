// import
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

// other
Vue.use(ElementUI)