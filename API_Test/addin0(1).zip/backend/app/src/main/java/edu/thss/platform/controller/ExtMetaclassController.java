package edu.thss.platform.controller;

import java.util.List;
import java.util.ArrayList;
import edu.thss.platform.controller.ResponseMsg;
import edu.thss.platform.service.modeler.bo.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("dwf/v1/ext/")
public class ExtMetaclassController {
    @GetMapping(path = "metaclass")
    public ResponseMsg<List<MetaClassBO>> listAllClasses(){
        List<MetaClassBO> result = new ArrayList();
        for(int i = 0;i < 5;i++){
            MetaClassBO item = new MetaClassBO();
            item.setDisplayName("测试" + i);
            item.setClassName("test" + i);
            result.add(item);
        }
        return new ResponseMsg<>(result);
    }
}