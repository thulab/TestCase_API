<template>
  <section>
    <el-button type="primary" @click="onClick">获取模型信息</el-button>
    <el-dialog
        title="extmetaclass"
        class="plug-details"
        :visible.sync="show"
        width="30%">
        <el-table
            :data="data"
            border
            style="width: 100%">
            <el-table-column
            prop="className"
            label="类名"
            width="120">
            </el-table-column>
            <el-table-column
            prop="displayName"
            label="显示名">
            </el-table-column>
        </el-table>
        <span slot="footer" class="dialog-footer">
            <el-button type="primary" @click="show = false">关 闭</el-button>
        </span>
    </el-dialog>
  </section>
</template>

<script>
import axios from 'axios';
export default {
  name: 'metaclass',
  data() {
    return {
      show: false,
      data: null
    }
  },
  methods: {
    onClick() {
      var that = this;
      axios.get("http://localhost:9090/dwf/v1/ext/metaclass").then(res => {
          var data = res.data.data;
          that.data = data;
          that.show = true;
      });
    }
  }
}
</script>

<style>

</style>