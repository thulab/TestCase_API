// import
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
// other
Vue.use(ElementUI)
// entry
entries = [
	{
		"name": "message",
		"note": "Hello World",
		"path": "modeler/message.vue",
		"module": "operation"
	},
	{
		"name": "metaclass",
		"note": "获取所有模块类名字",
		"path": "modeler/metaclass.vue",
		"module": "operation"
	}
]
name = "插件1"
description = "插件1的描述"